import pypandoc
output = pypandoc.convert_file('README.md', 'rst')